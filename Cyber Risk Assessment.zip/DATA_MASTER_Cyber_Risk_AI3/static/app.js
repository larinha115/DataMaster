'use strict';

// O HTML é autocontido: abrir via file:// oferece apenas uma prévia offline.
// As rotas /api/* precisam ser acessadas pela mesma origem do FastAPI.
const API_BASE = window.location.protocol.startsWith('http')
  ? window.location.origin : null;
const $ = id => document.getElementById(id);
const state = {
  controls: [], realControls: [], selectedImage: null, busy: false,
  connected: false, modelConfigured: false, mode: 'real', demoCases: [], demoCase: null
};

function showError(message) {
  $('erro-geral').textContent = message;
  $('erro-geral').style.display = 'block';
}
function clearError() { $('erro-geral').style.display = 'none'; }
function updateStep(number) {
  document.querySelectorAll('.step').forEach((item, index) => {
    item.classList.toggle('active', index + 1 === number);
    item.classList.toggle('done', index + 1 < number);
  });
}
function updateButton() {
  // O botão fica disponível depois do upload, mesmo sem chave, para
  // informar claramente o que falta em vez de parecer que não funciona.
  $('btn-analisar').disabled = state.busy || !state.connected ||
    (state.mode === 'demo' ? !state.demoCase : (!state.selectedImage || !$('controle_id').value));
}
function selectControl() {
  const control = state.controls.find(item => item.codigo === $('controle_id').value);
  if (control) {
    $('politica').value = control.descricao;
    $('hint-controle').textContent = '✓ ' + (control.nome || control.codigo);
    $('hint-controle').className = 'hint ok';
  } else {
    $('politica').value = '';
    $('hint-controle').textContent = 'Selecione um controle do catálogo.';
    $('hint-controle').className = 'hint erro';
  }
  updateButton();
}
function renderControls(controls) {
  state.controls = controls;
  const select = $('controle_id');
  select.replaceChildren();
  if (!controls.length) {
    select.add(new Option('Nenhum controle foi encontrado na fonte configurada', ''));
    showError('A fonte de controles está vazia. Verifique /health e a configuração CONTROLS_SOURCE.');
    updateButton();
    return;
  }
  for (const control of controls) {
    const option = new Option(control.nome ? `${control.codigo}: ${control.nome}` : control.codigo,
                              control.codigo);
    option.disabled = control.disponivel === false;
    select.add(option);
  }
  select.value = controls.find(c => c.disponivel !== false)?.codigo || '';
  selectControl();
}


async function loadDemoCases() {
  if (!API_BASE) return;
  try {
    const response = await fetch(API_BASE + '/api/demo/cases', {cache: 'no-store'});
    if (!response.ok) throw new Error('Cenários não disponíveis no servidor.');
    const cases = await response.json();
    if (!Array.isArray(cases) || cases.length !== 5) throw new Error('Pacote de cenários incompleto.');
    state.demoCases = cases;
    if (state.mode === 'demo') configureDemo();
  } catch {
    state.demoCases = [];
    if (state.mode === 'demo') showError('Cenários não encontrados. Execute a versão completa do projeto pelo servidor.');
  }
}

function clearRenderedResult() {
  $('resultado-ia').style.display = 'none';
  $('empty-state').style.display = 'flex';
  $('analysis-time').textContent = state.mode === 'demo' ? 'Cenário fictício • Sem IA' : 'Aguardando análise';
  $('json-bruto').style.display = 'none';
  $('result-origin').hidden = true;
  updateStep(1);
}

function configureDemo() {
  const select = $('demo-case-select');
  select.replaceChildren();
  if (!state.demoCases.length) {
    select.add(new Option('Cenários de demonstração não disponíveis', ''));
    state.demoCase = null;
    updateButton();
    return;
  }
  for (const scenario of state.demoCases) {
    select.add(new Option(scenario.titulo, scenario.id));
  }
  select.value = state.demoCase?.id && state.demoCases.some(c => c.id === state.demoCase.id)
    ? state.demoCase.id : state.demoCases[0].id;
  selectDemoCase();
}

function selectDemoCase() {
  if (state.mode !== 'demo') return;
  const c = state.demoCases.find(item => item.id === $('demo-case-select').value);
  clearError();
  clearRenderedResult();
  clearImage();
  state.demoCase = c || null;
  if (!c) return;
  renderControls([{...c.controle, disponivel: true}]);
  $('controle_id').disabled = true;
  const url = API_BASE + c.imagem_url;
  $('preview-img').src = url;
  $('preview-img').style.display = 'block';
  $('file-thumb').src = url;
  $('file-thumb').style.display = 'block';
  $('file-name').textContent = c.id + '.png • imagem sintética incluída no projeto';
  $('file-size').textContent = 'Arquivo ilustrativo fixo';
  $('file-chip').style.display = 'flex';
  $('remove-btn').hidden = true;
  updateStep(2); updateButton();
}

function changeMode(mode) {
  if (state.busy) return;
  state.mode = mode;
  clearError();
  clearRenderedResult();
  clearImage();
  $('mode-real').setAttribute('aria-pressed', String(mode === 'real'));
  $('mode-demo').setAttribute('aria-pressed', String(mode === 'demo'));
  $('demo-alert').hidden = mode !== 'demo';
  $('demo-field').hidden = mode !== 'demo';
  $('input-imagem').disabled = mode === 'demo';
  $('upload-area').classList.toggle('demo-locked', mode === 'demo');
  $('upload-area').querySelector('.upload-main').textContent = mode === 'demo'
    ? 'Evidência fictícia pré-carregada' : 'Arraste e solte a evidência aqui';
  $('upload-area').querySelector('.upload-sub').textContent = mode === 'demo'
    ? 'Para anexar uma imagem própria, volte para Análise real.'
    : 'ou clique para selecionar um arquivo • use apenas dados fictícios ou autorizados';
  $('btn-analisar').textContent = mode === 'demo' ? '▣ Exibir parecer ilustrativo' : '✦ Analisar Evidência';
  $('empty-subtitle').textContent = mode === 'demo'
    ? 'Escolha um cenário para exibir um parecer ilustrativo pré-cadastrado, sem chamada ao Gemini.'
    : 'Selecione um controle, anexe uma imagem e inicie a análise. O resultado da IA deverá ser validado por uma pessoa responsável.';
  $('confidence-label').textContent = mode === 'demo' ? 'Confiança da IA (não avaliada)' : 'Confiança qualitativa (IA)';
  $('step-3-label').textContent = mode === 'demo' ? 'Consultar exemplo' : 'Análise pela IA';
  $('right-title-label').textContent = mode === 'demo' ? 'Parecer ilustrativo' : 'Parecer da Análise';
  $('req-hint').textContent = mode === 'demo'
    ? 'Texto fictício incluído para apresentar a interface; não é uma política da sua empresa.'
    : 'Texto oficial recuperado no servidor pelo ID; não pode ser alterado nesta tela.';
  $('json-label').textContent = mode === 'demo'
    ? '</> Ver JSON do resultado ilustrativo' : '</> Ver resposta estruturada da IA (JSON)';
  $('controle_id').disabled = mode === 'demo';
  $('remove-btn').hidden = mode === 'demo';
  if (mode === 'demo') {
    configureDemo();
    if (!state.connected) showError('Inicie a API em http://127.0.0.1:8000/ para carregar os cenários locais. A chave Gemini não é necessária.');
  } else if (state.realControls.length) {
    renderControls(state.realControls);
  }
  updateButton();
}

async function runDemo() {
  if (state.busy || !state.connected || !state.demoCase) return;
  clearError();
  state.busy = true; updateButton(); updateStep(3);
  $('loading-label').textContent = 'Carregando parecer ilustrativo pré-cadastrado…';
  $('loading').style.display = 'block';
  $('resultado-ia').style.display = 'none';
  $('empty-state').style.display = 'none';
  try {
    const response = await fetch(API_BASE + '/api/demo/avaliar', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({case_id: state.demoCase.id})
    });
    if (!response.ok) throw new Error('Cenário não disponível (HTTP ' + response.status + ').');
    const result = await response.json();
    if (result.origem_resultado !== 'DEMONSTRACAO' || result.id_analise !== state.demoCase.id)
      throw new Error('Origem do resultado de demonstração não verificada.');
    renderResult(result);
    $('analysis-time').textContent = 'Exemplo ilustrativo • Sem inferência ao vivo';
    updateStep(4);
  } catch (error) {
    showError(error.message || 'Não foi possível obter o cenário de demonstração.');
    $('empty-state').style.display = 'flex'; updateStep(2);
  } finally {
    state.busy = false; updateButton(); $('loading').style.display = 'none';
  }
}

function previewOffline(reason) {
  const json = $('offline-catalog');
  const examples = json ? JSON.parse(json.textContent) : [];
  state.connected = false;
  state.modelConfigured = false;
  state.realControls = examples;
  if (state.mode === 'real') renderControls(examples);
  $('catalog-banner').hidden = false; // Exibir somente avisos de conexão / prévia sem API.
  $('catalog-banner').className = 'catalog-banner catalog-warning';
  $('catalog-banner').textContent =
    `PRÉVIA SEM API — ${examples.length} controles fictícios para conhecer a tela. ` +
    'A análise por IA está desativada. Para carregar sua planilha completa, ' +
    'inicie a API e abra http://127.0.0.1:8000/. ' + reason +
    ' O nome da coluna CONTROLES não causa este modo de prévia.';
  $('retry-controls').hidden = !API_BASE;
  $('server-link').hidden = Boolean(API_BASE);
  $('btn-analisar').title = 'Para analisar, execute o FastAPI e configure sua chave Gemini.';
  updateButton();
}

async function loadData() {
  // file:// não consegue carregar /static/app.js nem fazer fetch same-origin para a API.
  // O JS embutido e o catálogo fictício evitam a tela congelada em “Carregando…”.
  if (!API_BASE) {
    previewOffline('O arquivo HTML foi aberto diretamente, fora do servidor.');
    return;
  }
  await loadDemoCases();
  $('retry-controls').hidden = true;
  $('server-link').hidden = true;
  $('catalog-banner').hidden = true; // Não exibir status técnico ao conectar.
  $('catalog-banner').textContent = '';
  $('controle_id').replaceChildren(new Option('Conectando à API…', ''));
  clearError();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const [response, info] = await Promise.all([
      fetch(API_BASE + '/api/controles', {signal: controller.signal, cache: 'no-store'}),
      fetch(API_BASE + '/api/metadata', {signal: controller.signal, cache: 'no-store'})
    ]);
    if (!response.ok || !info.ok) {
      throw new Error(`A API retornou HTTP ${response.status}/${info.status}.`);
    }
    const controls = await response.json();
    const metadata = await info.json();
    if (!Array.isArray(controls)) throw new Error('O endpoint /api/controles não retornou uma lista.');
    state.connected = true;
    state.modelConfigured = Boolean(metadata.modelo_configurado);
    state.realControls = controls;
    if (state.mode === 'demo') configureDemo();
    else renderControls(controls);
    // A tela de uso normal não exibe detalhes técnicos de planilha/versão/chave.
    // Mantemos o aviso somente quando a API devolve o catálogo fictício de demonstração.
    $('catalog-banner').hidden = !metadata.exemplos_ficticios;
    $('catalog-banner').className = metadata.exemplos_ficticios
      ? 'catalog-banner catalog-warning' : 'catalog-banner';
    $('catalog-banner').textContent = metadata.exemplos_ficticios
      ? 'BASE DE DEMONSTRAÇÃO — Controles fictícios; configure a planilha para usar seus controles.'
      : '';
    $('btn-analisar').title = '';
    updateButton();
    if (state.mode === 'real' && state.selectedImage && !state.modelConfigured) {
      showError('A evidência foi carregada, mas a análise por IA ainda não está configurada. '
        + 'Preencha GOOGLE_API_KEY no arquivo .env da pasta do projeto e reinicie o servidor.');
    }
  } catch (error) {
    previewOffline('Falha ao acessar a API: ' +
      (error.name === 'AbortError' ? 'tempo de conexão excedido.' : error.message));
  } finally {
    clearTimeout(timeout);
  }
}

function clearImage() {
  $('input-imagem').value = '';
  state.selectedImage = null;
  $('preview-img').removeAttribute('src');
  $('preview-img').style.display = 'none';
  $('file-chip').style.display = 'none';
  $('file-thumb').style.display = 'none';
  updateStep(1);
  updateButton();
}

function attachImage(file) {
  if (state.mode === 'demo') return;
  clearError();
  if (!file) return;
  if (!['image/png', 'image/jpeg'].includes(file.type)) {
    clearImage(); showError('Formato inválido. Envie uma imagem PNG ou JPEG.'); return;
  }
  if (file.size > 8 * 1024 * 1024 || file.size === 0) {
    clearImage(); showError('A imagem deve ter entre 1 byte e 8 MB.'); return;
  }
  state.selectedImage = file;
  $('file-name').textContent = file.name;
  $('file-size').textContent = (file.size / 1024 / 1024).toFixed(2) + ' MB';
  const reader = new FileReader();
  reader.onload = () => {
    $('preview-img').src = reader.result;
    $('preview-img').style.display = 'block';
    $('file-thumb').src = reader.result;
    $('file-thumb').style.display = 'block';
    $('file-chip').style.display = 'flex';
  };
  reader.readAsDataURL(file);
  updateStep(2);
  updateButton();
  if (!state.connected) {
    showError('A evidência foi carregada, mas esta tela está em modo de prévia. '
      + 'Execute INICIAR_WINDOWS.bat e acesse http://127.0.0.1:8000/ para obter o parecer.');
  } else if (!state.modelConfigured) {
    showError('A evidência foi carregada, mas a análise por IA ainda não está configurada. '
      + 'Preencha GOOGLE_API_KEY no arquivo .env da pasta do projeto e reinicie o servidor.');
  }
}
function base64FromFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Erro na leitura do arquivo.'));
    reader.readAsDataURL(file);
  });
}
function populateList(id, items, empty) {
  const target = $(id);
  target.replaceChildren();
  for (const item of items?.length ? items : [empty]) {
    const li = document.createElement('li');
    li.textContent = item;
    target.append(li);
  }
}
function renderResult(data) {
  // Cada dimensão tem seu próprio julgamento e sua própria justificativa.
  const dimensions = [
    ['summary-design', data.desenho, 'reason-design'],
    ['summary-implementation', data.implementacao, 'reason-implementation'],
    ['summary-status', data.efetividade, 'reason-effectiveness'],
  ];
  for (const [valueId, evaluation, reasonId] of dimensions) {
    $(valueId).textContent = evaluation?.classificacao || '—';
    $(reasonId).textContent = evaluation?.justificativa || 'Não avaliado.';
    const card = $(valueId).closest('.summary-card');
    const category = evaluation?.classificacao || '';
    const good = ['ADEQUADO','IMPLEMENTADO','EFETIVO'].includes(category);
    const bad = ['INADEQUADO','INEFETIVO'].includes(category);
    card.className = 'summary-card ' + (good ? 'green' : 'blue');
    card.style.background = bad ? '#fff0f1' :
      ['PARCIAL','INSUFICIENTE','NÃO DEMONSTRADO','NÃO CONCLUSIVO'].includes(category) ? '#fff8e8' : '';
  }
  const tier = data.maturidade?.nivel;
  const validTier = Number.isInteger(tier) && tier >= 1 && tier <= 4;
  $('summary-level').textContent = validTier ? `Tier ${tier} de 4` : 'NÃO DETERMINADO';
  $('summary-level-name').textContent = validTier ? (data.nome_tier || '') : 'Evidência insuficiente';
  $('reason-tier').textContent = data.maturidade?.justificativa || 'Sem fundamentação recebida.';
  document.querySelectorAll('.maturity-node').forEach((item, ix) => {
    item.classList.toggle('active', validTier && ix + 1 === tier);
    item.classList.toggle('passed', validTier && ix + 1 < tier);
  });
  $('summary-confidence').textContent = data.confianca_ia || '—';
  const isDemo = data.origem_resultado === 'DEMONSTRACAO';
  $('review-alert').textContent = isDemo
    ? '⚠ Exemplo fictício pré-cadastrado: sem inferência ao vivo nem validação por especialista.'
    : data.revisao_humana_recomendada
      ? '⚠ Revisão humana recomendada: confira as quatro dimensões e as limitações da evidência.'
      : 'ⓘ Parecer preliminar: todas as dimensões exigem validação humana antes de decisão formal.';
  $('txt-justificativa').textContent = data.justificativa_analise || 'Sem justificativa recebida.';
  $('txt-parecer').textContent = data.sugestao_parecer || 'Sem parecer recebido.';
  populateList('lista-achados', data.achados_observaveis, 'Nenhum achado observável retornado.');
  populateList('lista-desvios', data.desvios_identificados, 'Nenhum desvio explícito identificado.');
  populateList('lista-limitacoes', data.limitacoes_da_evidencia, 'Nenhuma limitação adicional apontada.');
  $('json-bruto').textContent = JSON.stringify(data, null, 2);
  $('json-bruto').style.display = 'none';
  $('json-toggle').setAttribute('aria-expanded', 'false');
  $('json-arrow').textContent = '⌄';
  $('result-origin').hidden = !isDemo;
  $('confidence-label').textContent = isDemo ? 'Confiança IA (não avaliada)' : 'Confiança qualitativa (IA)';
  $('trace-info').textContent = isDemo
    ? `Cenário: ${data.id_analise} · Resultado ilustrativo fixo · Validação especialista: ${data.validacao_especialista || 'PENDENTE'} · Gemini não foi chamado`
    : `ID da análise: ${data.id_analise} · Modelo: ${data.modelo} · Prompt: ${data.versao_prompt} · Catálogo: ${data.versao_catalogo}`;
  $('empty-state').style.display = 'none';
  $('resultado-ia').style.display = 'block';
  $('analysis-time').textContent = 'Concluído: ' + new Date().toLocaleString('pt-BR');
}
async function runAudit() {
  if (state.mode === 'demo') { await runDemo(); return; }
  if (state.busy || !state.selectedImage || !$('controle_id').value) return;
  clearError();
  if (!state.connected || !API_BASE) {
    showError('Servidor não conectado. Inicie a API com INICIAR_WINDOWS.bat '
      + 'e abra http://127.0.0.1:8000/ para realizar a análise.');
    return;
  }
  if (!state.modelConfigured) {
    showError('A análise por IA está desativada porque GOOGLE_API_KEY não foi configurada. '
      + 'Abra o arquivo .env da pasta do projeto, preencha sua chave e reinicie o servidor.');
    return;
  }
  state.busy = true; updateButton(); updateStep(3);
  $('btn-analisar').textContent = 'Analisando…';
  $('loading-label').textContent = 'Analisando evidência com Gemini…';
  $('resultado-ia').style.display = 'none';
  $('empty-state').style.display = 'none';
  $('loading').style.display = 'block';
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 240000);
  try {
    const base64 = await base64FromFile(state.selectedImage);
    // Não enviamos política editável: o backend recupera o requisito oficial pelo ID.
    const response = await fetch(API_BASE + '/api/auditar', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      signal: controller.signal,
      body: JSON.stringify({controle_id: $('controle_id').value, imagem_base64: base64})
    });
    let data;
    try { data = await response.json(); }
    catch { throw new Error('O servidor retornou uma resposta inesperada. '
      + 'Verifique a janela do FastAPI e tente novamente.'); }
    if (!response.ok) {
      const detail = data.detail;
      const message = typeof detail === 'string' ? detail :
        detail && typeof detail.mensagem === 'string'
          ? `${detail.mensagem} [Código: ${detail.codigo || 'SEM_CODIGO'}]` +
            (Array.isArray(detail.campos) && detail.campos.length
              ? ` Campos: ${detail.campos.join(', ')}.` : '')
          : `Falha na análise (HTTP ${response.status}). Confira a janela do servidor.`;
      throw new Error(message);
    }
    renderResult(data);
    updateStep(4);
  } catch (error) {
    const message = error.name === 'AbortError'
      ? 'A análise ultrapassou 240 segundos. Verifique a conexão e o status da API antes de tentar novamente.'
      : error instanceof TypeError
        ? 'Não foi possível falar com o servidor. Confira http://127.0.0.1:8000/health e a janela da API.'
        : (error.message || 'Falha inesperada na auditoria.');
    showError(message);
    $('empty-state').style.display = 'flex';
    updateStep(2);
  } finally {
    clearTimeout(timeout);
    state.busy = false;
    $('loading').style.display = 'none';
    $('btn-analisar').textContent = '✦ Analisar Evidência';
    updateButton();
  }
}

$('mode-real').addEventListener('click', () => changeMode('real'));
$('mode-demo').addEventListener('click', () => changeMode('demo'));
$('demo-case-select').addEventListener('change', selectDemoCase);
$('controle_id').addEventListener('change', selectControl);
$('input-imagem').addEventListener('change', event => attachImage(event.target.files?.[0]));
$('remove-btn').addEventListener('click', clearImage);
$('btn-analisar').addEventListener('click', runAudit);
$('json-toggle').addEventListener('click', () => {
  const open = $('json-toggle').getAttribute('aria-expanded') === 'true';
  $('json-toggle').setAttribute('aria-expanded', String(!open));
  $('json-bruto').style.display = open ? 'none' : 'block';
  $('json-arrow').textContent = open ? '⌄' : '⌃';
});
const uploadArea = $('upload-area');
for (const eventName of ['dragenter', 'dragover']) uploadArea.addEventListener(eventName, event => {
  event.preventDefault(); uploadArea.classList.add('dragging');
});
for (const eventName of ['dragleave', 'drop']) uploadArea.addEventListener(eventName, event => {
  event.preventDefault(); uploadArea.classList.remove('dragging');
});
uploadArea.addEventListener('drop', event => {
  if (state.mode === 'real') attachImage(event.dataTransfer?.files?.[0]);
});
$('about-btn').addEventListener('click', () => $('about-dialog').showModal());
$('about-close').addEventListener('click', () => $('about-dialog').close());
$('retry-controls').addEventListener('click', loadData);
updateStep(1); loadData();
