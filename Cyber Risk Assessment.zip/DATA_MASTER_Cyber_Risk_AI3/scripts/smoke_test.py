"""Verifica infraestrutura local sem consumir créditos do Gemini."""
import json
from urllib.request import urlopen

BASE='http://127.0.0.1:8000'
for endpoint in ['/health','/api/metadata','/api/controles']:
    with urlopen(BASE+endpoint, timeout=10) as res:
        data=json.loads(res.read())
        assert res.status==200
        print(endpoint, 'OK', f'({len(data)} itens)' if isinstance(data,list) else data)
with urlopen(BASE+'/', timeout=10) as res:
    assert b'Cyber Risk Assessment' in res.read()
print('Front/API integrados; inferência REAL ainda requer teste com a sua GOOGLE_API_KEY.')
