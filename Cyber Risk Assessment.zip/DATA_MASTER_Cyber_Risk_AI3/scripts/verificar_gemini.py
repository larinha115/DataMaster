"""Diagnóstico de acesso ao Gemini; não imprime chaves nem mensagens brutas.

Uso: python scripts/verificar_gemini.py            # listar modelos disponíveis
     python scripts/verificar_gemini.py --test     # + 2 chamadas pequenas (podem custar)
"""
from __future__ import annotations

import argparse
import importlib.metadata
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import settings, ROOT
from inference import GEMINI_OUTPUT_SCHEMA


def classify(exc: Exception) -> str:
    code = getattr(exc, 'code', None) or getattr(exc, 'status_code', None)
    try:
        code = int(code)
    except (TypeError, ValueError):
        code = None
    msg = str(exc).lower()
    if code == 400 and 'schema' in msg:
        return 'HTTP 400: o modelo rejeitou o schema; a aplicação agora tenta JSON simples automaticamente.'
    if code == 400:
        return 'HTTP 400: requisição inválida; confira modelo, recursos e parâmetros aceitos.'
    if code in (401, 403):
        return f'HTTP {code}: chave sem autorização para o serviço/projeto ou restrição de acesso.'
    if code == 404:
        return 'HTTP 404: modelo não encontrado ou indisponível para esta chave/API.'
    if code == 429:
        return 'HTTP 429: limite de uso atingido; verifique quota e faturamento.'
    if code in (500, 502, 503, 504):
        return f'HTTP {code}: instabilidade temporária do provedor.'
    return f'Falha do tipo {type(exc).__name__}; consulte disponibilidade e versões, sem compartilhar sua chave.'


def main() -> int:
    p = argparse.ArgumentParser(description='Diagnóstico Gemini seguro para o DATA MASTER')
    p.add_argument('--test', action='store_true', help='Faz duas chamadas pequenas à API, com possível custo.')
    args = p.parse_args()
    print('DIAGNÓSTICO GEMINI — Cyber Risk Assessment')
    print('Arquivo .env:', 'encontrado' if (ROOT / '.env').is_file() else 'AUSENTE')
    print('Chave configurada:', 'SIM' if settings.google_api_key.strip() else 'NÃO')
    print('Modelo configurado:', settings.gemini_model)
    print('Modelo alternativo:', settings.gemini_fallback_model or 'não configurado')
    try:
        print('Versão google-genai:', importlib.metadata.version('google-genai'))
        from google import genai
        from google.genai import types
    except (ImportError, importlib.metadata.PackageNotFoundError):
        print('ERRO: google-genai não instalado. Rode: python -m pip install -U google-genai')
        return 2
    if not settings.google_api_key.strip():
        print('ERRO: preencha GOOGLE_API_KEY no arquivo .env e reinicie.')
        return 2

    client = genai.Client(api_key=settings.google_api_key)
    try:
        print('\n1) Listando modelos autorizados para generateContent...')
        try:
            names = []
            for model in client.models.list():
                actions = getattr(model, 'supported_actions', None) or []
                if actions and 'generateContent' not in actions:
                    continue
                name = str(model.name).removeprefix('models/')
                if name.startswith('gemini-') and not any(x in name for x in ('tts', 'image', 'live')):
                    names.append(name)
            for name in sorted(names):
                print('   ', name)
            if settings.gemini_model not in names:
                print('ATENÇÃO: o modelo principal não consta na lista da chave.')
                return 1
            print('OK: modelo principal autorizado.')
            if settings.gemini_fallback_model:
                if settings.gemini_fallback_model not in names:
                    print('ATENÇÃO: o modelo alternativo não consta na lista da chave.')
                    return 1
                print('OK: modelo alternativo autorizado (listado).')
        except Exception as exc:
            print('FALHOU models.list:', classify(exc))
            return 1

        if not args.test:
            print('\nOpcional: rode VERIFICAR_GEMINI.bat para testar geração de texto e JSON (2 chamadas).')
            return 0

        print('\n2) Teste mínimo de geração de texto (chamada real)...')
        try:
            basic = client.models.generate_content(model=settings.gemini_model, contents='Responda somente OK.')
            if not getattr(basic, 'text', None):
                print('FALHOU: nenhuma resposta de texto recebida.')
                return 1
            print('OK: geração simples disponível.')
        except Exception as exc:
            print('FALHOU geração de texto:', classify(exc))
            return 1

        print('\n3) Teste de JSON estruturado (chamada real)...')
        # Pequeno schema separado, sem dados pessoais ou corporativos.
        try:
            structured = client.models.generate_content(
                model=settings.gemini_model,
                contents='Responda no JSON exigido com status igual a OK.',
                config=types.GenerateContentConfig(
                    response_mime_type='application/json',
                    response_schema={'type':'OBJECT','properties':{'status':{'type':'STRING'}},'required':['status']},
                ),
            )
            if not getattr(structured, 'text', None) and getattr(structured, 'parsed', None) is None:
                print('FALHOU: JSON vazio.')
                return 1
            print('OK: JSON estruturado disponível.')
        except Exception as exc:
            print('FALHOU JSON estruturado:', classify(exc))
            return 1

        print('\nCONCLUÍDO: texto e schema simples funcionam; se upload continuar falhando,')
        print('verifique tamanho/formato da imagem e teste com uma evidência sintética.')
        return 0
    finally:
        client.close()


if __name__ == '__main__':
    sys.exit(main())
