"""Recompõe index.html autocontido após alterações em static/app.js.

O arquivo final pode ser aberto diretamente em modo PRÉVIA e, quando
servido pelo FastAPI, carrega o catálogo ativo via /api/controles.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent.parent
html_path = ROOT / 'index.html'
html = html_path.read_text(encoding='utf-8')
# Pode ser invocado várias vezes: partes são substituídas por comentários fixos.
start = '<!-- BEGIN GENERATED OFFLINE APP -->'
end = '<!-- END GENERATED OFFLINE APP -->'
if start in html and end in html:
    html = html[:html.index(start)] + '<!-- OFFLINE_DATA -->\n<!-- INLINE_APP -->' + html[html.index(end)+len(end):]

catalog = (ROOT / 'data/controles_demo.json').read_text(encoding='utf-8')
json.loads(catalog)
# Quebra a possibilidade de encerrar o elemento script por conteúdo do catálogo.
catalog = catalog.replace('<', '\\u003c')
js = (ROOT / 'static/app.js').read_text(encoding='utf-8')
if '</script' in js.lower():
    raise ValueError('Script contém </script, que exige escaping antes de ser embutido.')
insert = (start + '\n'
          '<script id="offline-catalog" type="application/json">\n' + catalog + '\n</script>\n'
          '<script>\n' + js + '\n</script>\n' + end)
html = html.replace('<!-- OFFLINE_DATA -->\n<!-- INLINE_APP -->', insert)
if start not in html or '<!-- INLINE_APP -->' in html:
    raise RuntimeError('Marcadores do template index.html não encontrados.')
html_path.write_text(html, encoding='utf-8')
print('index.html autocontido: OK')
