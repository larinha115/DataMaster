"""Checagem local sem chamar Gemini e sem exibir segredos."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import ROOT, settings
from catalog import load_catalog

print('Cyber Risk Assessment — diagnostico local')
print('Arquivo .env:', 'encontrado' if (ROOT/'.env').is_file() else 'AUSENTE')
print('GOOGLE_API_KEY:', 'PREENCHIDA (validade nao verificada)' if settings.google_api_key.strip() else 'AUSENTE')
print('Modelo configurado:', settings.gemini_model)
print('Fonte de controles:', settings.resolved_catalog_path.name)
try:
    c = load_catalog(settings.resolved_catalog_path, settings.controls_sheet)
    print('Controles lidos:', len(c.controls))
    print('Controles sem requisito:', len(c.unavailable))
except Exception as exc:
    print('ERRO ao ler catalogo:', type(exc).__name__, str(exc))
    sys.exit(1)
if not settings.google_api_key.strip():
    print('ACAO: preencha GOOGLE_API_KEY no arquivo .env, salve e reinicie INICIAR_WINDOWS.bat.')
else:
    print('PROXIMO PASSO: abra http://127.0.0.1:8000/ e teste com uma imagem sintética.')
