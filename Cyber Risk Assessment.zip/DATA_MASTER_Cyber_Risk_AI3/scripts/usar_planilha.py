"""Ativa uma cópia LOCAL da planilha privada, nunca a inclui no pacote publicado."""
from pathlib import Path
import re
import shutil
import sys

root = Path(__file__).resolve().parent.parent
name = 'SBK_Framework_NIST.xlsx'
private = root / 'data' / 'privado' / name
provided = root / name
if provided.is_file():
    private.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(provided, private)
elif not private.is_file():
    print(f'Planilha não localizada. Coloque {name} na pasta principal do projeto ou em data/privado/.')
    sys.exit(1)

env = root / '.env'
contents = env.read_text(encoding='utf-8') if env.is_file() else (root/'.env.example').read_text(encoding='utf-8')
line = 'CONTROLS_SOURCE=data/privado/' + name
if re.search(r'(?m)^CONTROLS_SOURCE=', contents):
    contents = re.sub(r'(?m)^CONTROLS_SOURCE=.*$', lambda m: line, contents)
else:
    contents += '\n'+line+'\n'
# Valida o arquivo e informa as colunas antes de mudar a configuração.
sys.path.insert(0, str(root))
from catalog import load_catalog
sheet_match = re.search(r'(?m)^CONTROLS_SHEET=(.+)$', contents)
sheet = sheet_match.group(1).strip() if sheet_match else 'PT-BR'
try:
    catalog = load_catalog(private, sheet)
except (ValueError, FileNotFoundError) as exc:
    print('ERRO AO LER PLANILHA:', exc)
    sys.exit(1)
env.write_text(contents, encoding='utf-8')
print('Planilha configurada:', private)
print('CONTROLES CARREGADOS:', len(catalog.controls))
print('COLUNAS DETECTADAS:', catalog.source_columns)
print('Inicie ou reinicie o servidor. Para usar a aplicacao, ABRA NO NAVEGADOR:')
print('http://127.0.0.1:8000/  (NAO abra index.html por duplo clique).')
