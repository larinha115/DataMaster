#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
source .venv/bin/activate
python -m uvicorn api3:app --host 127.0.0.1 --port 8000
