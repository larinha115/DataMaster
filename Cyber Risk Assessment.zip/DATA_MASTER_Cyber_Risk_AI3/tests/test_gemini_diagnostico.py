"""Testes offline do fallback restrito e validação após fallback."""
from __future__ import annotations

import json
import sys
import types as stdtypes

import pytest

from inference import GeminiAnalyzer, _schema_rejected

VALID = {
    'desenho': {'classificacao':'ADEQUADO','justificativa':'Política e responsabilidades formalmente documentadas no exemplo.'},
    'implementacao': {'classificacao':'PARCIAL','justificativa':'Parte dos ativos possui registros de execução documentados.'},
    'efetividade': {'classificacao':'NÃO CONCLUSIVO','justificativa':'Não há série temporal suficiente para comprovar a operação sustentada.'},
    'maturidade': {'nivel':3,'justificativa':'O cenário inclui processo formal e revisão periódica da gestão de riscos.'},
    'confianca_ia': 'MÉDIA',
    'achados_observaveis': ['Existe inventário com proprietário e revisão mensal.'],
    'justificativa_analise': 'O documento demonstra processo formal documentado com papéis claros.',
    'desvios_identificados': [],
    'limitacoes_da_evidencia': ['Não há provas longitudinais de melhoria contínua.'],
    'sugestao_parecer': 'Parecer preliminar: revisar amostras e aprovações antes de encerrar.',
}


class ProviderError(Exception):
    def __init__(self, code, msg):
        self.code = code
        super().__init__(msg)


def setup_fake_sdk(monkeypatch, errors=None, output=None):
    errors = list(errors or [])
    calls = []
    output = VALID if output is None else output
    class FakeModels:
        def generate_content(self, *, model, contents, config):
            calls.append({'model': model, 'contents': contents, 'config': config})
            if errors:
                raise errors.pop(0)
            return stdtypes.SimpleNamespace(parsed=None, text=json.dumps(output, ensure_ascii=False))

    fake_models = FakeModels()
    class FakeClient:
        def __init__(self, **kwargs):
            self.models = fake_models
        def close(self): pass

    genai = stdtypes.ModuleType('google.genai')
    genai.Client = FakeClient
    types = stdtypes.ModuleType('google.genai.types')
    types.GenerateContentConfig = lambda **kwargs: kwargs
    types.Part = stdtypes.SimpleNamespace(from_bytes=lambda data, mime_type: (data, mime_type))
    google = stdtypes.ModuleType('google')
    google.genai = genai
    genai.types = types
    monkeypatch.setitem(sys.modules, 'google', google)
    monkeypatch.setitem(sys.modules, 'google.genai', genai)
    monkeypatch.setitem(sys.modules, 'google.genai.types', types)
    return calls


def analyze():
    return GeminiAnalyzer('testing-only', 'gemini-test').analyze('PR.IP-4','Backups','Backup diário', b'xyz', 'image/png')


def test_schema_rejection_400_retries_once_without_schema(monkeypatch):
    calls = setup_fake_sdk(monkeypatch, [ProviderError(400, 'Invalid response_schema: unsupported field')])
    result = analyze()
    assert result.maturidade.nivel == 3
    assert len(calls) == 2
    assert 'response_schema' in calls[0]['config']
    assert 'response_schema' not in calls[1]['config']
    assert calls[1]['config']['response_mime_type'] == 'application/json'


def test_non_schema_400_is_not_retried(monkeypatch):
    calls = setup_fake_sdk(monkeypatch, [ProviderError(400, 'Invalid image content')])
    with pytest.raises(ProviderError): analyze()
    assert len(calls) == 1


def test_fallback_still_validates_locally(monkeypatch):
    calls = setup_fake_sdk(monkeypatch, [ProviderError(400, 'response_schema unsupported')],
                           output={**VALID, 'maturidade': {'nivel':7, 'justificativa':'Nível inválido no teste sintético'}})
    with pytest.raises(ValueError): analyze()
    assert len(calls) == 3  # schema rejeitado; JSON sem schema invalido; retry de formato tambem invalido


def test_no_schema_retry_on_429():
    assert not _schema_rejected(ProviderError(429, 'response_schema unsupported'))
