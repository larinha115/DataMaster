"""Garante que o usuário não veja um seletor eternamente preso em 'Carregando...' ao abrir o HTML."""
from pathlib import Path
import json
import re
from config import ROOT


def test_html_has_embedded_offline_js_and_demo_controls():
    html=(ROOT/'index.html').read_text(encoding='utf-8')
    assert '<script src="/static/app.js"' not in html
    assert 'function previewOffline(reason)' in html
    assert "if (!API_BASE) {" in html
    assert 'Tentar conectar à API novamente' in html
    assert 'Abrir aplicação pelo servidor' in html
    match=re.search(r'<script id="offline-catalog" type="application/json">(.*?)</script>', html, re.S)
    assert match, 'Catálogo fictício embutido ausente.'
    controls=json.loads(match.group(1))
    assert len(controls)==10
    assert all({'codigo','nome','descricao'} <= c.keys() for c in controls)
    assert all('FICTÍCI' not in c['nome'].upper() for c in controls)


def test_real_catalog_does_not_display_technical_status_banner():
    html = (ROOT/'index.html').read_text(encoding='utf-8')
    js = (ROOT/'static/app.js').read_text(encoding='utf-8')
    assert 'id="catalog-banner" class="catalog-banner" role="status" hidden' in html
    assert 'PLANILHA ATIVA:' not in html
    assert 'PLANILHA ATIVA:' not in js
    assert "$('catalog-banner').hidden = !metadata.exemplos_ficticios" in js
    assert "$('catalog-banner').hidden = false" in js  # offline warnings remain visible


def test_inconclusivo_display_preserves_technical_status():
    js=(ROOT/'static/app.js').read_text(encoding='utf-8')
    html=(ROOT/'index.html').read_text(encoding='utf-8')
    for source in (js, html):
        assert "data.efetividade" in source
        assert "NÃO CONCLUSIVO" in source
        assert "JSON.stringify(data, null, 2)" in source
        assert "data.revisao_humana_recomendada" in source
