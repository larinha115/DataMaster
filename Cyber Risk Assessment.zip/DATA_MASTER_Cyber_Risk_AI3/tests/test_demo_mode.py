"""O modo de demonstração jamais deve ser confundido com análise por IA."""
from pathlib import Path

from fastapi.testclient import TestClient
from api3 import app, get_analyzer
from demo_mode import demo_cases
from config import ROOT

client = TestClient(app)


def test_five_fixed_cases_without_api_key(monkeypatch):
    # Nenhuma dependência de chave, Google, planilha ou analisador.
    def fail_if_called():
        raise AssertionError('O Gemini não deve ser instanciado no modo demo')
    app.dependency_overrides[get_analyzer] = fail_if_called
    try:
        r = client.get('/api/demo/cases')
        assert r.status_code == 200
        cases = r.json()
        assert [c['id'] for c in cases] == [f'DEMO-0{i}' for i in range(1, 6)]
        assert all(c['origem'] == 'CENARIO_FICTICIO_PRE_CADASTRADO' for c in cases)
        # O cenário não revela o resultado no endpoint de seleção.
        assert all('resultado' not in c and 'nota_esperada' not in c for c in cases)
        for n, c in enumerate(cases, start=1):
            response = client.post('/api/demo/avaliar', json={'case_id': c['id']})
            assert response.status_code == 200, response.text
            body = response.json()
            assert body['maturidade']['nivel'] == [1,2,3,3,4][n-1]
            assert all(body[k]['justificativa'] for k in ('desenho','implementacao','efetividade','maturidade'))
            assert body['origem_resultado'] == 'DEMONSTRACAO'
            assert body['confianca_ia'] == 'NÃO APLICÁVEL'
            assert body['validacao_especialista'] == 'PENDENTE'
            assert body['revisao_humana_recomendada'] is True
            assert body['versao_prompt'] == 'NAO_APLICAVEL'
            assert 'Nenhum' in body['modelo']
            assert body['id_controle'] == c['controle']['codigo']
    finally:
        app.dependency_overrides.pop(get_analyzer, None)


def test_image_routes_are_real_png_and_only_five_ids_allowed():
    for n in range(1, 6):
        r = client.get(f'/api/demo/imagens/DEMO-0{n}')
        assert r.status_code == 200
        assert r.headers['content-type'] == 'image/png'
        assert r.content.startswith(b'\x89PNG\r\n\x1a\n')
        assert len(r.content) > 10_000
    assert client.get('/api/demo/imagens/../casos.json').status_code in (404, 422)
    assert client.get('/api/demo/imagens/OUTRO').status_code == 404


def test_rejects_uploads_and_arbitrary_evidence_in_demo():
    assert client.post('/api/demo/avaliar', json={'case_id': 'DESCONHECIDO'}).status_code == 422
    assert client.post('/api/demo/avaliar', json={'case_id': 'DEMO-01', 'imagem_base64': 'pretend'}).status_code == 422
    assert client.post('/api/demo/avaliar', json={'case_id': 'DEMO-01', 'controle_id': 'XX'}).status_code == 422


def test_no_private_data_or_fake_benchmark_metrics_in_demo():
    source = (ROOT / 'data/demo_scenarios/casos.json').read_text(encoding='utf-8')
    assert 'google_api_key' not in source.lower()
    assert 'validacao_especialista' in source
    assert set(c['resultado']['efetividade']['classificacao'] for c in demo_cases().values()) == {
        'INEFETIVO', 'PARCIAL', 'EFETIVO', 'NÃO CONCLUSIVO'
    }
    # Separação entre resultados roteirizados e o benchmark que executa chamadas reais.
    evaluator = (ROOT / 'benchmark/evaluate.py').read_text(encoding='utf-8')
    assert 'demo_scenarios/casos.json' not in evaluator


def test_frontend_labels_and_modes_are_explicit():
    html = (ROOT / 'index.html').read_text(encoding='utf-8')
    script = (ROOT / 'static/app.js').read_text(encoding='utf-8')
    assert 'id="mode-demo"' in html
    assert 'id="mode-real"' in html
    assert 'id="demo-case-select"' in html
    assert 'id="result-origin"' in html
    assert 'RESULTADO ILUSTRATIVO' in html
    assert "if (state.mode === 'demo') { await runDemo(); return; }" in script
    assert "API_BASE + '/api/demo/avaliar'" in script
    assert "API_BASE + '/api/auditar'" in script
    assert 'NÃO APLICÁVEL' not in (ROOT / 'schemas.py').read_text(encoding='utf-8')  # real output remains restricted
