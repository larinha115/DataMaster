"""Valida fallback de disponibilidade de maneira totalmente offline, sem chave ou custo."""
import json
import sys
import types as stdtypes
import pytest

from inference import GeminiAnalyzer
from tests.test_gemini_diagnostico import VALID, ProviderError


def fake_sdk(monkeypatch, outcomes):
    """outcomes: dict modelo -> fila de erros/respostas (ausência = resposta válida)."""
    calls = []
    class FakeModels:
        def generate_content(self, *, model, contents, config):
            calls.append((model, config))
            queue = outcomes.get(model, [])
            if queue:
                outcome = queue.pop(0)
                if isinstance(outcome, Exception):
                    raise outcome
                return stdtypes.SimpleNamespace(parsed=None, text=json.dumps(outcome))
            return stdtypes.SimpleNamespace(parsed=None, text=json.dumps(VALID))
    models = FakeModels()
    class FakeClient:
        def __init__(self, **kwargs): self.models=models
        def close(self): pass
    g = stdtypes.ModuleType('google')
    genai=stdtypes.ModuleType('google.genai')
    typ=stdtypes.ModuleType('google.genai.types')
    genai.Client=FakeClient
    typ.GenerateContentConfig=lambda **k: k
    typ.Part=stdtypes.SimpleNamespace(from_bytes=lambda **k:k)
    genai.types=typ
    g.genai=genai
    monkeypatch.setitem(sys.modules,'google',g)
    monkeypatch.setitem(sys.modules,'google.genai',genai)
    monkeypatch.setitem(sys.modules,'google.genai.types',typ)
    return calls


def analyze(a):
    return a.analyze('PR.IP-4','Backups','Política aprovada',b'1234','image/png')


def test_http503_fallback_to_authorized_alternative(monkeypatch):
    calls=fake_sdk(monkeypatch, {'primary':[ProviderError(503,'server overloaded')], 'alternative':[]})
    a=GeminiAnalyzer('test','primary','alternative')
    assert analyze(a).maturidade.nivel == 3
    assert [m for m,_ in calls] == ['primary','alternative']
    assert a.attempted_fallback is True
    assert a.last_model_used == 'alternative'


def test_503_without_configured_fallback_not_retried_by_app(monkeypatch):
    calls=fake_sdk(monkeypatch, {'primary':[ProviderError(503,'server overloaded')]})
    a=GeminiAnalyzer('test','primary')
    with pytest.raises(ProviderError) as e: analyze(a)
    assert e.value.code == 503
    assert [m for m,_ in calls] == ['primary']


@pytest.mark.parametrize('code',[400,401,403,404,429])
def test_no_fallback_for_nontransient_errors(monkeypatch,code):
    calls=fake_sdk(monkeypatch, {'primary':[ProviderError(code,'invalid or exhausted')], 'alternative':[]})
    a=GeminiAnalyzer('test','primary','alternative')
    with pytest.raises(ProviderError): analyze(a)
    assert [m for m,_ in calls]==['primary']
    assert a.attempted_fallback is False


def test_503_both_models_down_reports_failure(monkeypatch):
    calls=fake_sdk(monkeypatch, {'primary':[ProviderError(503,'down')],
                                'alternative':[ProviderError(503,'down too')]})
    a=GeminiAnalyzer('test','primary','alternative')
    with pytest.raises(ProviderError): analyze(a)
    assert [m for m,_ in calls]==['primary','alternative']
    assert a.attempted_fallback is True


def test_503_fallback_must_validate_output(monkeypatch):
    calls=fake_sdk(monkeypatch, {'primary':[ProviderError(503,'down')],
                                'alternative':[{**VALID,'maturidade': {'nivel':6, 'justificativa':'Teste de valor inválido'}}, {**VALID,'maturidade': {'nivel':6, 'justificativa':'Teste de valor inválido'}}]})
    a=GeminiAnalyzer('test','primary','alternative')
    with pytest.raises(ValueError): analyze(a)
    assert [m for m,_ in calls] == ['primary', 'alternative', 'alternative']
    assert a.last_model_used=='alternative'


def test_same_model_does_not_fallback(monkeypatch):
    calls=fake_sdk(monkeypatch,{'primary':[ProviderError(503,'down')]})
    a=GeminiAnalyzer('test','primary','primary')
    with pytest.raises(ProviderError): analyze(a)
    assert len(calls)==1
