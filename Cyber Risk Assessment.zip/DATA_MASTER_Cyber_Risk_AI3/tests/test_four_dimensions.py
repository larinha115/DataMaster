"""Regras da nova avaliação: quatro dimensões independentes e Tier não forçado."""
from io import BytesIO
import base64
from fastapi.testclient import TestClient
from PIL import Image
import pytest
from pydantic import ValidationError

from api3 import app, get_analyzer, get_catalog
from catalog import load_catalog
from config import ROOT
from schemas import GeminiAnalysis, AuditResponse, TIER
from inference import _parse_analysis, InvalidModelResponse
from types import SimpleNamespace

BASE = {
    'desenho':{'classificacao':'ADEQUADO','justificativa':'O procedimento define responsáveis, frequência e escopo do controle.'},
    'implementacao':{'classificacao':'NÃO DEMONSTRADO','justificativa':'A imagem não contém prova de execução em produção.'},
    'efetividade':{'classificacao':'NÃO CONCLUSIVO','justificativa':'Não existem registros longitudinais que comprovem funcionamento sustentado.'},
    'maturidade':{'nivel':None,'justificativa':'Sem elementos de governança organizacional, não é possível indicar Tier.'},
    'confianca_ia':'BAIXA',
    'achados_observaveis':['Há somente uma política aprovada, sem logs de execução.'],
    'justificativa_analise':'Documento formal existe, mas não comprova execução, efetividade nem Tier.',
    'desvios_identificados':[],
    'limitacoes_da_evidencia':['Faltam registros de operação e evidências de governança.'],
    'sugestao_parecer':'Solicitar amostra temporal de execução, testes e documentação de gestão de riscos.',
}

def payload():
    buf=BytesIO();Image.new('RGB',(40,40),'white').save(buf,'PNG')
    return {'controle_id':'PR.IP-4','imagem_base64':'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()}

def test_independent_dimensions_and_null_tier_are_valid():
    result=GeminiAnalysis.model_validate(BASE)
    assert result.desenho.classificacao=='ADEQUADO'
    assert result.implementacao.classificacao=='NÃO DEMONSTRADO'
    assert result.efetividade.classificacao=='NÃO CONCLUSIVO'
    assert result.maturidade.nivel is None

def test_null_tier_requires_documented_limitation():
    with pytest.raises(ValidationError):
        GeminiAnalysis.model_validate({**BASE,'limitacoes_da_evidencia':[]})

@pytest.mark.parametrize('dimension,field,value',[
    ('desenho','classificacao','EXCELENTE'),
    ('implementacao','classificacao','NÃO IMPLEMENTADO'),
    ('efetividade','classificacao','REQUER REVISÃO HUMANA'),
    ('maturidade','nivel',5),
])
def test_invalid_labels_or_tier_5_are_rejected(dimension,field,value):
    bad={**BASE,dimension:{**BASE[dimension],field:value}}
    with pytest.raises(ValidationError):GeminiAnalysis.model_validate(bad)

def test_missing_dimension_rejected_before_emitting_parecer():
    missing={k:v for k,v in BASE.items() if k!='desenho'}
    with pytest.raises(InvalidModelResponse) as exc:
        _parse_analysis(SimpleNamespace(parsed=missing,candidates=[]))
    assert exc.value.reason=='CAMPOS_AUSENTES'
    assert exc.value.fields==('desenho',)

def test_all_four_nist_tiers_present_and_exact():
    assert [TIER[i][0] for i in range(1,5)]==['Partial','Risk-Informed','Repeatable','Adaptive']

def test_api_keeps_design_adequate_even_when_other_dimensions_inconclusive():
    class Analyzer:
        last_model_used='gemini-test-mock'
        def analyze(self,*args):return GeminiAnalysis.model_validate(BASE)
    app.dependency_overrides[get_catalog]=lambda:load_catalog(ROOT/'data/controles_demo.json')
    app.dependency_overrides[get_analyzer]=lambda:Analyzer()
    try:
        with TestClient(app) as client:
            response=client.post('/api/auditar',json=payload())
        assert response.status_code==200,response.text
        r=response.json()
        assert r['desenho']['classificacao']=='ADEQUADO'
        assert r['implementacao']['classificacao']=='NÃO DEMONSTRADO'
        assert r['efetividade']['classificacao']=='NÃO CONCLUSIVO'
        assert r['maturidade']['nivel'] is None and r['nome_tier'] is None
        assert r['revisao_humana_recomendada'] is True
        assert r['origem_resultado']=='MODELO_IA'
    finally:app.dependency_overrides.clear()

def test_frontend_four_cards_and_four_individual_justifications():
    html=(ROOT/'index.html').read_text(encoding='utf8')
    js=(ROOT/'static/app.js').read_text(encoding='utf8')
    for key in ['summary-design','summary-implementation','summary-status','summary-level',
                'reason-design','reason-implementation','reason-effectiveness','reason-tier']:
        assert f'id="{key}"' in html
    assert 'Tier 1' not in html or 'Partial' in html
    assert 'Tier ${tier} de 4' in js
    assert 'NÃO DETERMINADO' in js
    assert 'data.desenho' in js and 'data.implementacao' in js and 'data.efetividade' in js
