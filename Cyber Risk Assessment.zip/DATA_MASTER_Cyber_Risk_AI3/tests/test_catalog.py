from pathlib import Path
import pytest
from catalog import load_catalog, normalize_header, split_subcategory
from config import ROOT


def test_demo_catalog_has_10_controls_and_requirements():
    catalog = load_catalog(ROOT / 'data/controles_demo.json')
    assert len(catalog.controls) == 10
    assert catalog.get('ID.AM-4').nome == 'Catálogo de sistemas de informação externos'
    assert catalog.get('PR.IP-4').descricao
    assert len(catalog.digest) == 12


def test_split_preserves_code_and_name():
    assert split_subcategory('ID.GV-1: A política está estabelecida') == ('ID.GV-1','A política está estabelecida')


def test_normalizes_ptbr_column_headers():
    assert normalize_header('Sub-categoria') == 'subcategoria'
    assert normalize_header('Definição de controles') == 'definicaodecontroles'


def test_catalog_rejects_duplicate_ids(tmp_path):
    path = tmp_path / 'catalog.json'
    path.write_text('[{"codigo":"PR.IP-4","nome":"X","descricao":"A"},'
                    '{"codigo":"PR.IP-4","nome":"Y","descricao":"B"}]', encoding='utf-8')
    with pytest.raises(ValueError, match='duplicados'):
        load_catalog(path)

@pytest.mark.parametrize('header_name', ['CONTROLES', 'Controles', 'Sub-categoria'])
def test_excel_accepts_controles_header_and_separates_requirement(monkeypatch, tmp_path, header_name):
    """Cabeçalho pode vir depois de linhas de título e usar CONTROLES."""
    import pandas as pd
    import catalog as module
    book = tmp_path / 'sample.xlsx'
    book.write_bytes(b'fake-workbook-for-monkeypatch')
    first_rows = pd.DataFrame([
        ['FRAMEWORK NIST', ''],
        ['', ''],
        [header_name, 'Definição de controles'],
    ])
    content = pd.DataFrame({
        header_name: ['ID.AM-1: Inventário de ativos', 'PR.AC-3: Acesso remoto'],
        'Definição de controles': ['Manter inventário atualizado.', 'Exigir MFA.']
    })

    def fake_read_excel(path, sheet_name, header=None, **kwargs):
        assert sheet_name == 'PT-BR'
        return first_rows if header is None else content

    monkeypatch.setattr(pd, 'read_excel', fake_read_excel)
    catalog = module.load_catalog(book)
    assert len(catalog.controls) == 2
    assert catalog.get('ID.AM-1').nome == 'Inventário de ativos'
    assert catalog.get('ID.AM-1').descricao == 'Manter inventário atualizado.'
    assert catalog.source_columns['controles'] == header_name
    assert catalog.source_columns['requisito'] == 'Definição de controles'


def test_controles_header_with_policy_name(monkeypatch, tmp_path):
    import pandas as pd
    import catalog as module
    book = tmp_path / 'another.xlsx'
    book.write_bytes(b'another-fake-workbook')
    monkeypatch.setattr(pd, 'read_excel', lambda *args, **kwargs: (
        pd.DataFrame([['CONTROLES', 'Requisito da Política (Regra de Negócio)']])
        if kwargs.get('header') is None else
        pd.DataFrame({'CONTROLES':['ID.AM-1: Inventário de ativos'],
                      'Requisito da Política (Regra de Negócio)':['Política fictícia']})
    ))
    catalog = module.load_catalog(book)
    assert catalog.get('ID.AM-1').descricao == 'Política fictícia'
