"""Novo benchmark 4D: não reaproveita gabarito 1/5 para Tiers."""
import csv
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1] / 'benchmark'))
from evaluate import calculate_metrics

def test_metrics_do_not_invent_results():
    key=[{'case_id':'E001','desenho':'ADEQUADO','implementacao':'IMPLEMENTADO',
          'efetividade':'EFETIVO','tier':'3','validacao_especialista':'PENDENTE'}]
    assert calculate_metrics([],key)['total_gabarito_validado']==0
    assert calculate_metrics([{'case_id':'E001','tier':'3'}],key)['total_avaliado']==0
    key[0]['validacao_especialista']='VALIDADO'
    pred=[{'case_id':'E001','desenho':'ADEQUADO','implementacao':'PARCIAL',
           'efetividade':'EFETIVO','tier':'2'}]
    result=calculate_metrics(pred,key)
    assert result['metricas']['desenho']['acuracia_exata']==1.0
    assert result['metricas']['implementacao']['acuracia_exata']==0.0
    assert result['metricas']['tier']['erro_absoluto_medio']==1.0

def test_all_20_benchmark_fixtures_are_present_and_unlabeled():
    root=Path(__file__).resolve().parents[1]/'benchmark'
    with (root/'manifest.csv').open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
    assert len(rows)==20 and len({r['case_id'] for r in rows})==20
    for r in rows:
        assert (root/'evidencias'/r['arquivo']).is_file()
        assert 'nota' not in r['arquivo'].lower()
    with (root/'gabarito_para_validacao.csv').open(newline='',encoding='utf8') as f:key=list(csv.DictReader(f))
    assert len(key)==20
    assert all(r['validacao_especialista']=='PENDENTE' and not r['tier'] for r in key)
