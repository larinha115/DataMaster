"""Regressões: parecer não aparece e a interface não explica o motivo."""
from dataclasses import replace
from pathlib import Path
import base64
from io import BytesIO

import pytest
from fastapi.testclient import TestClient
from PIL import Image

import api3
from catalog import load_catalog
from config import ROOT


def valid_payload():
    b = BytesIO()
    Image.new('RGB', (40, 40), 'white').save(b, format='PNG')
    return {'controle_id': 'PR.IP-4', 'imagem_base64':
            'data:image/png;base64,' + base64.b64encode(b.getvalue()).decode('ascii')}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(api3, 'settings', replace(api3.settings, google_api_key=''))
    api3.app.dependency_overrides[api3.get_catalog] = lambda: load_catalog(ROOT / 'data/controles_demo.json')
    with TestClient(api3.app) as c:
        yield c
    api3.app.dependency_overrides.clear()


def test_missing_api_key_returns_explicit_503(client):
    response = client.post('/api/auditar', json=valid_payload())
    assert response.status_code == 503
    assert 'GOOGLE_API_KEY' in response.json()['detail']


@pytest.mark.parametrize('code, expected_status, phrase', [
    (401, 502, 'chave'),
    (403, 502, 'permissões'),
    (404, 502, 'modelo'),
    (429, 429, 'limite de uso'),
    (503, 503, 'temporariamente'),
    (500, 502, 'HTTP 500'),
    (502, 502, 'HTTP 502'),
    (400, 502, 'HTTP 400'),
])
def test_provider_failure_is_explained_without_leaking_secrets(client, code, expected_status, phrase):
    class FakeProviderError(Exception):
        def __init__(self):
            self.code = code
            super().__init__('sensitive-secret-value')

    class FailingAnalyzer:
        def analyze(self, *args):
            raise FakeProviderError()

    api3.app.dependency_overrides[api3.get_analyzer] = lambda: FailingAnalyzer()
    response = client.post('/api/auditar', json=valid_payload())
    assert response.status_code == expected_status
    assert phrase.lower() in response.json()['detail'].lower()
    assert 'sensitive-secret-value' not in response.text


def test_frontend_explains_missing_key_but_hides_catalog_banner():
    js = (ROOT / 'static/app.js').read_text(encoding='utf-8')
    html = (ROOT / 'index.html').read_text(encoding='utf-8')
    assert 'A evidência foi carregada, mas a análise por IA ainda não está configurada.' in js
    assert 'A análise por IA está desativada porque GOOGLE_API_KEY não foi configurada.' in js
    assert "!state.connected || !state.modelConfigured;" not in js
    assert 'PLANILHA ATIVA:' not in html
    assert 'A análise por IA está desativada porque GOOGLE_API_KEY' in html
    assert 'signal: controller.signal' in js


def test_both_models_unavailable_reports_no_parecer(client):
    class ProviderError(Exception):
        code = 503
    class BothDown:
        attempted_fallback = True
        def analyze(self, *args):
            raise ProviderError('never expose evidence or secret')
    api3.app.dependency_overrides[api3.get_analyzer] = lambda: BothDown()
    response = client.post('/api/auditar', json=valid_payload())
    assert response.status_code == 503
    assert 'modelo alternativo' in response.json()['detail']
    assert 'never expose' not in response.text
