"""Regressões da falha 'O modelo não retornou um parecer no formato esperado'."""
import base64
import json
from io import BytesIO
from types import SimpleNamespace
from fastapi.testclient import TestClient
from PIL import Image
import pytest

from tests.test_gemini_diagnostico import VALID
from inference import GeminiAnalyzer, InvalidModelResponse, _parse_analysis
import api3
from config import ROOT
from catalog import load_catalog


def response(*, data=None, text=None, reason=None):
    if data is not None:
        text = json.dumps(data, ensure_ascii=False)
    candidates = [SimpleNamespace(finish_reason=reason)] if reason else []
    return SimpleNamespace(parsed=None, text=text, candidates=candidates)


def test_plain_json_and_fenced_json_are_validated():
    assert _parse_analysis(response(data=VALID)).maturidade.nivel == 3
    assert _parse_analysis(response(text='```json\n' + json.dumps(VALID) + '\n```')).maturidade.nivel == 3
    assert _parse_analysis(SimpleNamespace(parsed=VALID, candidates=[])).maturidade.nivel == 3


@pytest.mark.parametrize('r,reason,fields', [
    (response(text=None), 'RESPOSTA_VAZIA', ()),
    (response(text='{"status_controle"'), 'JSON_INVALIDO', ()),
    (response(data={k:v for k,v in VALID.items() if k != 'sugestao_parecer'}),
     'CAMPOS_AUSENTES', ('sugestao_parecer',)),
    (response(data={**VALID,'maturidade': {'nivel':8, 'justificativa':'Teste de valor inválido'}}), 'CAMPOS_INVALIDOS', ('maturidade',)),
    (response(text='{"x":1',reason='MAX_TOKENS'), 'RESPOSTA_TRUNCADA', ()),
    (response(text=None,reason='SAFETY'), 'RESPOSTA_BLOQUEADA', ()),
])
def test_categorizes_without_returning_model_content(r, reason, fields):
    with pytest.raises(InvalidModelResponse) as exc:
        _parse_analysis(r)
    assert exc.value.reason == reason
    assert exc.value.fields == fields


def fake_sdk(monkeypatch, results):
    import sys
    import types as builtin_types
    calls = []
    results = list(results)
    class FakeModels:
        def generate_content(self, *, model, contents, config):
            calls.append((model,contents,config))
            return results.pop(0)
    class FakeClient:
        def __init__(self, **kwargs): self.models = FakeModels()
        def close(self): pass
    genai = builtin_types.ModuleType('google.genai')
    genai.Client = FakeClient
    types = builtin_types.ModuleType('google.genai.types')
    types.GenerateContentConfig = lambda **kwargs: kwargs
    types.Part = SimpleNamespace(from_bytes=lambda **kwargs: kwargs)
    google = builtin_types.ModuleType('google')
    google.genai = genai
    genai.types = types
    monkeypatch.setitem(sys.modules, 'google', google)
    monkeypatch.setitem(sys.modules, 'google.genai', genai)
    monkeypatch.setitem(sys.modules, 'google.genai.types', types)
    return calls


def do_analyze(analyzer):
    return analyzer.analyze('PR.IP-4','Backups','Backups diários',b'test','image/png')


def test_one_retry_with_original_image_and_offline_corrected_response(monkeypatch):
    calls = fake_sdk(monkeypatch, [response(text='{invalid}'), response(data=VALID)])
    analyzer = GeminiAnalyzer('test', 'model', format_retry=True)
    result = do_analyze(analyzer)
    assert result.maturidade.nivel == 3
    assert len(calls) == 2
    assert calls[0][1][-1] == calls[1][1][-1]
    assert 'IMPORTANTE' in calls[1][1][0]
    assert calls[1][2]['max_output_tokens'] > calls[0][2]['max_output_tokens']


def test_incomplete_response_rejected_twice_never_emits_parecer(monkeypatch):
    calls = fake_sdk(monkeypatch, [response(data={**VALID,'maturidade': {'nivel':8, 'justificativa':'Teste de valor inválido'}}),
                                  response(data={**VALID,'maturidade': {'nivel':8, 'justificativa':'Teste de valor inválido'}})])
    with pytest.raises(InvalidModelResponse) as exc:
        do_analyze(GeminiAnalyzer('test', 'model', format_retry=True))
    assert exc.value.reason == 'CAMPOS_INVALIDOS'
    assert len(calls) == 2


def test_blocked_output_does_not_retry(monkeypatch):
    calls = fake_sdk(monkeypatch, [response(reason='SAFETY')])
    with pytest.raises(InvalidModelResponse) as exc:
        do_analyze(GeminiAnalyzer('test', 'model'))
    assert exc.value.reason == 'RESPOSTA_BLOQUEADA'
    assert len(calls) == 1


def test_retry_may_be_disabled(monkeypatch):
    calls = fake_sdk(monkeypatch, [response(text='bad-json')])
    with pytest.raises(InvalidModelResponse):
        do_analyze(GeminiAnalyzer('test', 'model', format_retry=False))
    assert len(calls) == 1


def test_api_exposes_reason_not_raw_reply(monkeypatch):
    class Broken:
        def analyze(self, *args):
            raise InvalidModelResponse('CAMPOS_AUSENTES', ('sugestao_parecer',))
    app = api3.app
    app.dependency_overrides[api3.get_catalog] = lambda: load_catalog(ROOT / 'data/controles_demo.json')
    app.dependency_overrides[api3.get_analyzer] = lambda: Broken()
    buf=BytesIO(); Image.new('RGB',(40,40),'white').save(buf,'PNG')
    payload={'controle_id':'PR.IP-4', 'imagem_base64':'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()}
    try:
        with TestClient(app) as client:
            result = client.post('/api/auditar', json=payload)
        assert result.status_code == 502
        detail = result.json()['detail']
        assert detail['codigo'] == 'CAMPOS_AUSENTES'
        assert detail['campos'] == ['sugestao_parecer']
        assert 'sugestao_parecer' not in detail['mensagem']
        assert 'imagem_base64' not in result.text
    finally:
        app.dependency_overrides.clear()


def test_frontend_shows_new_safe_error_and_old_inconclusive_label():
    script=(ROOT / 'static/app.js').read_text(encoding='utf8')
    html=(ROOT / 'index.html').read_text(encoding='utf8')
    assert 'detail.mensagem' in script and 'detail.mensagem' in html
    assert "data.efetividade" in script and "NÃO CONCLUSIVO" in script
    assert 'PLANILHA ATIVA:' not in html
