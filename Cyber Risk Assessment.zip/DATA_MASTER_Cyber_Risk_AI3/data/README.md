# Fontes de controles

`controles_demo.json` contém regras **sintéticas** derivadas do escopo dos controles escolhidos; não são textos normativos oficiais nem dados corporativos. É a base padrão para a apresentação reproduzível.

Para usar a planilha privada da usuária, salve-a **apenas em ambiente autorizado** como `data/privado/SBK_Framework_NIST.xlsx` e defina `CONTROLS_SOURCE=data/privado/SBK_Framework_NIST.xlsx`. O carregador localiza a linha de cabeçalho da aba PT-BR automaticamente e separa as colunas `CONTROLES` ou `Sub-categoria` (ID/nome) e `Definição de controles` ou `Requisito da Política` (texto do requisito). O diretório `data/privado/` está no `.gitignore`; **não publique o XLSX original em Git**.
