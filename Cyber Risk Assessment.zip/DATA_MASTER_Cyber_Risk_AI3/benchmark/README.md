# Benchmark de quatro critérios

As 20 imagens sintéticas foram produzidas para um experimento legado de notas 1 e 5. **As notas legadas não são Tiers NIST** e não foram convertidas automaticamente. O arquivo `gabarito_para_validacao.csv` está intencionalmente sem classificações e marcado PENDENTE; um especialista deve rotular separadamente desenho, implementação, efetividade e Tier indicativo (1–4 ou `NA`).

Depois de validar o gabarito (marque `VALIDADO`), execute `python benchmark/evaluate.py --run --limit 2` para gerar previsões reais, considerando quota/custo, ou `--predictions caminho.csv` para pontuar resultados existentes. O modo de demonstração NÃO é usado no benchmark. Os resultados são preliminares até a validação humana.
