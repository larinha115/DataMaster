"""Benchmark das quatro dimensões; só pontua gabarito validado por especialista.

As 20 imagens foram originalmente produzidas para outro rubric 1–5. Elas não
possuem gabarito 4D/Tier; NÃO mapear notas antigas para Tiers automaticamente.
"""
from __future__ import annotations
import argparse
import base64
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from urllib import request, error

ROOT = Path(__file__).resolve().parent
FIELDS = ('desenho','implementacao','efetividade','tier')
ALLOWED = {
    'desenho': {'ADEQUADO','PARCIAL','INADEQUADO','INSUFICIENTE'},
    'implementacao': {'IMPLEMENTADO','PARCIAL','NÃO DEMONSTRADO'},
    'efetividade': {'EFETIVO','PARCIAL','INEFETIVO','NÃO CONCLUSIVO'},
    'tier': {'1','2','3','4','NA'},
}

def read_csv(path: Path) -> list[dict]:
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))

def calculate_metrics(predictions: list[dict], answer_key: list[dict]) -> dict:
    valid = {r['case_id']:r for r in answer_key if r.get('validacao_especialista')=='VALIDADO'
             and all(str(r.get(k,'')).strip() in ALLOWED[k] for k in FIELDS)}
    if not valid:
        return {'total_gabarito_validado':0,'total_avaliado':0,
                'aviso':'Gabarito 4D/Tier ainda sem validação de especialistas; métricas não calculadas.'}
    pairs = [(valid[r['case_id']],r) for r in predictions if r.get('case_id') in valid]
    result={'total_gabarito_validado':len(valid),'total_avaliado':len(pairs),'metricas':{}}
    for field in FIELDS:
        comparable=[(str(a[field]),str(p.get(field,''))) for a,p in pairs if str(p.get(field,'')) in ALLOWED[field]]
        result['metricas'][field]={
            'amostras':len(comparable),
            'acuracia_exata':round(sum(a==b for a,b in comparable)/len(comparable),4) if comparable else None,
        }
        if field=='tier':
            numerical=[(int(a),int(b)) for a,b in comparable if a!='NA' and b!='NA']
            result['metricas'][field]['erro_absoluto_medio']=(round(sum(abs(a-b) for a,b in numerical)/len(numerical),4)
                if numerical else None)
            result['metricas'][field]['taxa_nao_determinado']=(round(sum(b=='NA' for _,b in comparable)/len(comparable),4)
                if comparable else None)
    result['limites']='Somente gabaritos 4D validados são pontuados; Tiers são indicativos por controle, não classificação oficial NIST da organização.'
    return result

def run_benchmark(api: str, limit: int, delay: float) -> list[dict]:
    cases=read_csv(ROOT/'manifest.csv')[:limit or None]
    out=[]
    for i,c in enumerate(cases,1):
        image=(ROOT/'evidencias'/c['arquivo']).read_bytes()
        payload=json.dumps({'controle_id':c['controle_id'],
            'imagem_base64':'data:image/png;base64,'+base64.b64encode(image).decode()}).encode()
        req=request.Request(api.rstrip('/')+'/api/auditar',data=payload,
                            headers={'Content-Type':'application/json'},method='POST')
        try:
            with request.urlopen(req,timeout=180) as response:
                obj=json.loads(response.read())
            row={'case_id':c['case_id'], 'desenho':obj['desenho']['classificacao'],
                 'implementacao':obj['implementacao']['classificacao'],
                 'efetividade':obj['efetividade']['classificacao'],
                 'tier':str(obj['maturidade']['nivel']) if obj['maturidade']['nivel'] is not None else 'NA',
                 'id_analise':obj['id_analise'],'origem_resultado':obj['origem_resultado']}
            if row['origem_resultado']!='MODELO_IA':raise ValueError('Resposta não gerada por IA')
        except (error.URLError,ValueError,KeyError) as exc:
            row={'case_id':c['case_id'],'erro':type(exc).__name__}
        out.append(row)
        print(f'{i}/{len(cases)} {c["case_id"]}: {row.get("erro", "resposta recebida")}')
        if delay and i<len(cases):time.sleep(delay)
    return out

def main():
    p=argparse.ArgumentParser(description='Benchmark 4D; NÃO executa chamadas sem --run')
    modes=p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--run',action='store_true')
    modes.add_argument('--predictions',type=Path)
    p.add_argument('--api',default='http://127.0.0.1:8000')
    p.add_argument('--limit',type=int,default=0)
    p.add_argument('--delay',type=float,default=1.0)
    p.add_argument('--gabarito',type=Path,default=ROOT/'gabarito_para_validacao.csv')
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    predictions=run_benchmark(args.api,args.limit,args.delay) if args.run else read_csv(args.predictions)
    if args.run:
        dest=args.out or ROOT/'resultados'/('previsoes_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.csv')
        dest.parent.mkdir(parents=True,exist_ok=True)
        with dest.open('w',encoding='utf8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['case_id',*FIELDS,'id_analise','origem_resultado','erro'])
            w.writeheader();w.writerows([{k:r.get(k,'') for k in w.fieldnames} for r in predictions])
        print('Previsões salvas em:',dest)
    print(json.dumps(calculate_metrics(predictions,read_csv(args.gabarito)),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
