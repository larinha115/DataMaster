# Critérios independentes do Cyber Risk Assessment 3.0

O catálogo fornecido usa identificadores de controles da geração anterior do CSF (por exemplo, PR.IP-4), enquanto os Tiers indicativos são os quatro Implementation Tiers do CSF 2.0. Esses conceitos são apresentados separadamente, sem afirmar que o identificador de controle pertence ao Core 2.0.

O parecer é preliminar e tem quatro dimensões independentes, cada uma com `classificacao`/`nivel` e `justificativa`. **Uma única imagem raramente prova as quatro dimensões**; falta de evidência não é sinônimo de falha comprovada. O requisito do controle é obtido no servidor pelo ID selecionado.

| Dimensão | Pergunta | Saídas permitidas | Evidências úteis |
|---|---|---|---|
| Desenho | O controle foi concebido adequadamente? | ADEQUADO, PARCIAL, INADEQUADO, INSUFICIENTE | Política, procedimento, RACI, escopo, frequência, exceções e critérios de controle. |
| Implementação | O controle foi colocado em prática? | IMPLEMENTADO, PARCIAL, NÃO DEMONSTRADO | Configurações, registros de implantação, cobertura, execução, tickets e aprovações. |
| Efetividade | Operou como desenhado e de forma sustentada? | EFETIVO, PARCIAL, INEFETIVO, NÃO CONCLUSIVO | Histórico de operação, testes, amostragem temporal, falhas, tratamento de exceções e revalidação. |
| Maturidade | Há indícios de governança e gestão de riscos associados ao controle? | Tier indicativo 1–4 ou **NÃO DETERMINADO** (`nivel: null`) | Governança, papéis, decisões informadas por risco, consistência, métricas, incidentes, integração e melhoria contínua. |

## NIST CSF 2.0 Implementation Tiers — referência indicativa

- **Tier 1 — Partial:** gestão de riscos fragmentada, ad hoc e sem aplicação consistente.
- **Tier 2 — Risk-Informed:** decisões consideram riscos, mas ainda não há integração e padronização uniformes.
- **Tier 3 — Repeatable:** políticas, processos e responsabilidades formalizados, implementados e revisados regularmente.
- **Tier 4 — Adaptive:** gestão adaptativa, integrada e aprimorada continuamente com base em métricas, ameaças e incidentes.

**Ressalva metodológica:** NIST CSF 2.0 e NIST SP 1302 aplicam Tiers a perfis e práticas organizacionais de governança e gestão de risco. O campo `maturidade.nivel` é uma **inferência indicativa relacionada ao controle**, nunca um Tier oficial da organização. Se a evidência não mostrar práticas de governança, use `null`; **não force Tier 1** por ausência de informação. Consulte https://doi.org/10.6028/NIST.SP.1302 e https://doi.org/10.6028/NIST.CSWP.29.

## Exemplo de saída válida

```json
{
  "desenho": {"classificacao":"ADEQUADO","justificativa":"A política define responsabilidades, escopo e frequência."},
  "implementacao": {"classificacao":"NÃO DEMONSTRADO","justificativa":"Não há registros de implantação."},
  "efetividade": {"classificacao":"NÃO CONCLUSIVO","justificativa":"Não há histórico de operação."},
  "maturidade": {"nivel":null,"justificativa":"Não há evidência suficiente de governança organizacional."}
}
```

Os demais campos da API registram achados, desvios, limitações, confiança qualitativa, parecer, origem e rastreabilidade. `revisao_humana_recomendada` é sinalizada para evidências insuficientes, classificações não conclusivas, Tier não determinado, confiança abaixo de ALTA ou limitações registradas. O parecer nunca equivale a aprovação formal.
