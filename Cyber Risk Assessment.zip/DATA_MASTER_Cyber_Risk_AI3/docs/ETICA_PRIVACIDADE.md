# Ética, privacidade, segurança e uso responsável

## Premissas

- Esta versão opera com **imagens e requisitos sintéticos** por padrão. O workbook corporativo não acompanha o pacote público.
- Com uma API key configurada, **a imagem e o requisito selecionado são enviados ao serviço externo Gemini**, de acordo com a configuração do usuário e as condições do provedor. O app não garante retenção zero pelo provedor; validar contratos e políticas aplicáveis antes de processar informações reais.
- A ferramenta auxilia a pessoa analista. Ela **não determina conformidade regulatória** nem substitui parecer formal, auditoria independente ou responsável de controle.

## Controles implementados

1. **Minimização:** somente ID + requisito correspondente + imagem necessária à avaliação são usados no modelo; planilha inteira não é enviada.
2. **Proteção do cliente contra políticas alteradas:** backend lê o requisito autoritativo por ID e rejeita divergência enviada pelo cliente.
3. **Upload:** aceita PNG/JPEG, valida assinatura, tamanho e dimensões, verifica integridade e recodifica removendo metadados de arquivo (inclusive EXIF/GPS quando presentes).
4. **Não persistência local:** as imagens e os resultados não são gravados pelo servidor. Logs opcionais contêm apenas metadados operacionais mínimos.
5. **Instruções defensivas:** o prompt manda ignorar comandos e notas embutidos nas evidências e não inventar elementos não observáveis.
6. **Separação de confiança e acurácia:** ALTA/MÉDIA/BAIXA é avaliação qualitativa da evidência declarada pelo modelo, não um percentual calibrado de confiabilidade.
7. **Revisão humana:** status inconclusivo, confiança não alta ou limitações indicadas ativam `revisao_humana_recomendada`; todo parecer é declarado preliminar.
8. **Credenciais:** a chave é obtida por variável de ambiente e nunca impressa no console; `.env` está fora do Git.

## Riscos e controles ainda pendentes antes de produção

| Risco | Mitigação necessária |
|---|---|
| Dados pessoais/sigilosos legíveis na imagem | Política de dados aprovados; anonimização/redação humana ou automática testada antes de envio; base legal e análise de necessidade. |
| Prompt injection oculto em screenshot | Red team com exemplos adversariais; monitoramento; limite de ações (o sistema não executa comandos extraídos da imagem). Prompt sozinho não elimina risco. |
| Erro do modelo ou falsa confiança | Validação humana, amostra revisada por SME, benchmark com cenários ambíguos e acompanhamento contínuo de erros. |
| Exposição da API local em rede | Autenticação, autorização, rate limiting, logging aprovado e HTTPS; esta versão liga a API a localhost ao executar pelo comando documentado. |
| Retenção e transferência internacional no provedor | Avaliação de fornecedor, termos e retenção aplicáveis ao contrato/conta usados; envolver privacidade, jurídico e segurança antes de uso real. |
| Reprodução acidental de dados internos | Repositório público sem XLSX privado, `.env`, resultados contendo PII ou evidências reais; revisão antes do commit. |
| Logs e relatórios ausentes para auditoria formal | Caso operacional aprovado: repositório criptografado, retenção por política, versionamento do documento e trilha de aprovadores. |

## Cenários cobertos em testes

Política adulterada; controle inexistente; tipo MIME divergente; imagem inválida; remoção de EXIF; confiança qualitativa média acionando revisão; existência de exemplos cegos. Ainda falta testar extração de texto sensível **visível**, ataques complexos de prompt injection, autenticação e integração real com o provedor.
