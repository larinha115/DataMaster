# Arquitetura e fluxo de dados

```mermaid
flowchart TD
    U[Analista / navegador] -->|GET /api/controles| API[FastAPI]
    U -->|ID + evidência PNG/JPG| API
    API --> VAL[Validação de formato e tamanho]
    VAL --> SAN[Decodificação e remoção de metadados]
    API --> CAT[Catálogo local autoritativo]
    CAT -->|JSON sintético ou XLSX privado| API
    SAN --> INF[Adaptador de inferência]
    API -->|ID + nome + requisito oficial| INF
    INF -->|Imagem sanitizada + contexto| GEM[Gemini multimodal]
    GEM -->|JSON com quatro critérios independentes, orientado por schema| INF
    INF --> PY[Pydantic: validação de estrutura]
    PY --> R[Resposta estruturada + revisão humana]
    R --> U
```

## Decisões de implementação

**Fronteira de confiança:** o navegador envia somente o ID e a imagem. Mesmo que envie `politica` no formato da API antiga, um valor diferente do requisito carregado no backend resulta em HTTP **409**. A planilha/JSON local é a fonte autoritativa. O campo de requisito exibido no frontend é `readonly`, mas a proteção está no servidor, não no HTML.

**Separação de responsabilidades:** `catalog.py` transforma a fonte tabular em `{codigo,nome,descricao}`. `api3.py` valida o request e as imagens. `inference.py` executa o adaptador do provedor. `prompts.py` contém instruções versionadas. `schemas.py` valida entrada, decisão e resposta final. O JavaScript lida apenas com estado da interface e renderização segura (`textContent`, sem inserir HTML do modelo no DOM).

**Preparação da fonte XLSX:** a planilha original possui linha introdutória antes do cabeçalho; o importador busca `Sub-categoria` e `Definição de controles` entre as primeiras dez linhas. Depois, separa `ID.AM-1: Nome` em duas propriedades. Controles cuja definição está vazia ou marcada NA/N/A continuam visíveis, mas ficam desabilitados para auditoria; nenhum requisito é inventado.

**Preparação de imagens:** valida tipo declarado e assinatura binária, limite de 8 MB e 20 milhões de pixels; verifica integridade com Pillow e recodifica a imagem para remover EXIF. O texto visível não é anonimizado automaticamente: apenas dados fictícios/autorizados devem entrar. O app não grava imagens em disco nem salva transcrições ou pareceres.

**Orquestração:** chamada única e síncrona ao Gemini, sem múltiplos agentes e sem ferramentas externas. A API usa `def` síncrono para que FastAPI execute a operação bloqueante em threadpool. `response_schema` define tipos e opções permitidas, e o servidor valida novamente a saída. Um modelo indisponível causa HTTP 502/503, sem parecer inventado.

**Metadados e rastreabilidade:** cada resposta contém `id_analise` não identificável, `modelo`, versão do prompt e hash abreviado da versão da fonte de controles. Se `AUDIT_LOG_ENABLED=true`, os logs guardam ID da análise, controle, Tier indicativo/efetividade, latência e versões — **não** imagens, PII, prompt integral ou corpo da resposta.

**Restrições:** nenhuma autenticação ou controle de acesso para múltiplos usuários nesta versão; usar apenas localmente/dentro de ambiente autorizado. O backend impede envio arbitrário de regras, mas não consegue provar autenticidade da imagem nem impedir falsificações de origem. O Gemini pode errar, especialmente diante de imagens incompletas ou adulteradas.
