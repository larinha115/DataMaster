# Roteiro de apresentação — DATA MASTER

## Mensagem principal

“O objetivo não foi pedir a uma IA que diga se um print parece bom. Foi projetar um processo reproduzível que confronta evidências visuais com requisitos autoritativos e entrega um **parecer preliminar estruturado, rastreável e sujeito à revisão humana**.”

## Demonstração sugerida (8–12 minutos dentro da sessão de 1h30)

**Plano A com quota:** faça uma inferência real sobre evidência sintética e identifique no JSON `origem_resultado: MODELO_IA`.
**Plano B sem quota:** clique em **Demonstração** no cabeçalho, selecione um dos cinco cenários PR.IP-4 e mostre o fluxo de imagens e pareceres ilustrativos. Explique antes de começar que os cinco pareceres são textos roteirizados, sem inferência do Gemini ou validação de auditor; no JSON aparecerá `origem_resultado: DEMONSTRACAO` e `confianca_ia: NÃO APLICÁVEL`. Se houver tempo, retorne a **Análise real** para demonstrar o contrato da API e a gestão de erros 429/503, sem prometer concluir a inferência.

O modo sem quota **não** prova desempenho do Gemini; o benchmark continua exigindo testes com inferências reais e gabarito revisado por especialistas.


1. **Problema (1 min):** análise manual de evidências de controles de segurança é trabalhosa e tem variabilidade entre avaliadores.
2. **Arquitetura (2 min):** navegador → FastAPI → catálogo autoritativo → Gemini multimodal → schema Pydantic → parecer. Mostre `docs/ARQUITETURA.md`.
3. **Fluxo (3–4 min):** `GET /health` confirma fonte/modelo, selecione um controle, confira nome e requisito separados, carregue `benchmark/evidencias/E001.png`, execute a inferência com chave configurada e mostre as quatro avaliações independentes, suas justificativas, limitações e JSON.
4. **Governança (1 min):** envie propositalmente um requisito alterado na documentação `/docs` e demonstre HTTP 409; a política do navegador não substitui a regra do servidor.
5. **Avaliação (2 min):** mostre `benchmark/gabarito_para_validacao.csv` **depois** da inferência, rode o avaliador em previsões reais e explique por que o gabarito 4D ainda exige validação antes de calcular acurácia e MAE.
6. **Trade-offs e próximos passos (2 min):** um modelo multimodal em vez de OCR+LLM/RAG, proteção de dados, ausência de uso real sem autorização, expansão do benchmark e SSO antes de produção.

Se faltar conexão ou quota, use o modo Demonstração e **declare que os pareceres exibidos são ilustrativos pré-cadastrados, não resultados gerados pela IA**.

## Perguntas prováveis e respostas técnicas

- **Por que não RAG?** A seleção por ID resolve exatamente a regra em uma fonte estruturada; RAG agregaria complexidade e risco de recuperar outro controle. Seria útil com corpus documental grande e consulta aberta.
- **Por que não fine-tuning?** Ainda não há exemplos auditados suficientes; primeiro medir o baseline e as lacunas.
- **Como impede que uma pessoa mude a política?** O requisito vem do servidor. O HTML é leitura, e a API bloqueia `politica` divergente com HTTP 409.
- **O JSON garante verdade?** Não. Garante **estrutura**; fatos precisam ser confrontados com evidência e validados por especialistas.
- **Tier 4 em um controle prova maturidade da organização?** Não. Os Tiers NIST CSF 2.0 descrevem governança e gestão de riscos organizacionais; o resultado é apenas indicativo e requer validação humana e evidências de abrangência.
- **Confiança ALTA é 90%?** Não. É confiança **qualitativa declarada pelo modelo** e deve ser calibrada empiricamente, se for usada em decisões.
- **Dados vão para onde?** O conteúdo selecionado é enviado ao serviço configurado do Gemini. O app não guarda imagem, mas termos/retenção do fornecedor precisam ser avaliados antes de dados reais.
- **Como sei que funciona em outra máquina?** Ambiente configurável, catálogo sintético incluso, `requirements.txt`, Docker, testes automatizados e smoke test. Chave é fornecida pelo operador autorizado.
