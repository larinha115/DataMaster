# Justificativa tecnológica e trade-offs

| Decisão | Por que foi escolhida | Alternativa e trade-off |
|---|---|---|
| FastAPI + Pydantic | API enxuta com OpenAPI e contratos formais de dados; facilita teste com mocks. | Framework full stack adicionaria recursos de autenticação, mas também complexidade. |
| Gemini multimodal | Analisa imagem e requisito textual em uma chamada. | OCR + LLM: maior controle do texto intermediário, porém mais passos e perda potencial de layout. |
| Catálogo local por ID | Fonte pequena, estruturada e precisa; reduz recuperação irrelevante e protege a política de alterações no navegador. | RAG vetorial seria útil para documentos extensos e perguntas abertas, mas aqui adiciona indexação e risco de recuperação equivocada. |
| Sem fine-tuning inicial | Poucos casos rotulados e tarefas guiadas por requisito; demonstrar baseline antes de escolher ajuste de pesos. | Fine-tuning requer exemplos validados, governança de versões e medição de generalização. |
| Schema + validação Pydantic | Reduz variabilidade de estrutura e falha explicitamente se o modelo responder fora do contrato. | Apenas instruir por prompt é menos robusto; schema não garante veracidade de conteúdo. |
| Temperatura baixa (0,1) | Busca reduzir variação entre chamadas para facilitar avaliação. | Determinismo completo não é garantido pelo serviço externo. |
| Requisito oficial só no servidor | Evita que um usuário modifique silenciosamente a política para manipular o resultado. | Edição livre favorece experimentos, mas demanda modo de teste explícito e trilha de aprovação. |
| Sem persistência de evidências | Menor exposição local de documentos potencialmente sigilosos. | Sem histórico auditável local; em produção seria necessário repositório aprovado, criptografia, segregação e retenção formal. |
| Resposta humana no processo | Exibe limitações e revisão recomendada, em vez de aprovar automaticamente controles. | Automação de decisão seria mais rápida, mas inapropriada sem avaliação e governança sólidas. |
| JSON de demonstração separado do XLSX privado | Facilita entrega reproduzível sem publicar dados organizacionais. | Reproduzir o case com a base real exige copiar a planilha autorizada fora do Git. |

## O que NÃO foi implementado

- **RAG:** o controle exato é recuperado por chave primária; avaliar RAG somente se o escopo evoluir para múltiplas políticas longas e consultas abertas.
- **Fine-tuning:** não existe base validada de volume adequado; baseline primeiro.
- **Multiagentes:** uma única tarefa de inferência com contrato limitado; um segundo agente só se justificaria com ganho demonstrado no benchmark e custo/latência aceitáveis.
- **Indicador probabilístico de confiança:** a classificação ALTA/MÉDIA/BAIXA vem do modelo e não é calibração estatística. Medir concordância com especialistas antes de convertê-la em percentual.
