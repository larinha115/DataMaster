# Roadmap de evolução

**Para a apresentação:** configurar chave de teste, executar `pytest`, executar smoke test com a API iniciada, verificar `/health`, testar ao vivo ao menos uma evidência de cenário 1 e uma de cenário 5, verificar se o modelo reconhece falta de evidência e salvar previsões reais do benchmark. Não apresentar resultado quantitativo antes de medir.

**Próxima iteração:** validar gabarito com SME, expandir para todas as notas 1–5, medir acurácia por controle e consistência entre execuções, adicionar casos adversariais e comparar modelos/prompts com custo e latência observados.

**Evolução corporativa:** SSO/RBAC, rate limiting, aprovação de fontes documentais, repositório criptografado com trilha de auditoria e retenção, revisão humana formal, avaliação de fornecedor de IA e conformidade de proteção de dados. Avaliar OCR+LLM ou RAG apenas se novos casos de uso justificarem o aumento de complexidade.
