# Matriz de rastreabilidade — requisitos DATA MASTER

| Requisito do edital | Evidência neste pacote | Situação e condição de encerramento |
|---|---|---|
| Solução funcional de IA generativa | `api3.py`, `inference.py`, `index.html` | Implementada; integração real depende da chave autorizada e teste em ambiente de execução. |
| Um ou mais modelos de IA | `inference.py`, `config.py` | Gemini multimodal configurável. |
| Prompts / orquestração para consistência | `prompts.py`, `schemas.py`, `api3.py` | Versionamento + schema + avaliação conservadora implementados; medir estabilidade empiricamente. |
| Dados de empresa fictícia e preparação/uso | `data/controles_demo.json`, `catalog.py`, `benchmark/evidencias` | Catálogo fictício incluído; planilha privada opcional; fluxo de preparação documentado. |
| Estratégia de modelo (RAG, fine-tuning etc.) e avaliação | `docs/DECISOES_TRADEOFFS.md`, `docs/AVALIACAO.md`, `benchmark/evaluate.py` | Estratégia justificada; execução quantitativa real pendente até obter chave e gabarito validado. |
| Desenho da arquitetura, decisões, trade-offs | `docs/ARQUITETURA.md`, `docs/DECISOES_TRADEOFFS.md` | Documentado com diagrama Mermaid e alternativas consideradas. |
| Ética, privacidade, responsabilidade | `docs/ETICA_PRIVACIDADE.md`, `api3.py`, `prompts.py` | Controles de protótipo implementados; riscos restantes declarados, sem afirmar prontidão bancária. |
| Projeto empacotado e reproduzível | ZIP, `requirements.txt`, `Dockerfile`, `compose.yaml`, `.env.example` | Entregue; execução real requer chave do usuário. |
| Scripts de configuração/instalação/execução no Git | `README.md`, `requirements.txt`, `scripts/smoke_test.py`, `Dockerfile` | Inclusos no pacote; publicação em repositório Git depende da usuária. |
| Instruções para executar em outra máquina | `README.md` | Disponíveis para Windows, Linux/macOS e Docker. |
| Explicação do case | `README.md`, `docs/APRESENTACAO.md` | Documentado. |
| Decisões e trade-offs | `docs/DECISOES_TRADEOFFS.md` | Documentado. |
| Próximos passos | `docs/PROXIMOS_PASSOS.md` | Documentado. |
| Apresentação do case e demonstração | `docs/APRESENTACAO.md` | Roteiro entregue; apresentação real pendente. |

| Plano de contingência para a demo ao vivo | `demo_mode.py`, `data/demo_scenarios/`, seletor de modo no `index.html` | Cinco pareceres ilustrativos sem Gemini; claramente rotulados; não entram no benchmark. |
