# Estratégia de avaliação do modelo 4D

## Hipóteses mensuráveis

1. O modelo distingue corretamente **desenho, implementação, efetividade e Tier indicativo**, sem derivar automaticamente uma dimensão de outra.
2. Uma política formal pode demonstrar desenho ADEQUADO sem provar implementação ou efetividade.
3. Falta de registros não deve ser rotulada automaticamente como INEFETIVO ou Tier 1: use NÃO CONCLUSIVO / NÃO DETERMINADO conforme o caso.
4. O schema é válido e cada dimensão apresenta justificativa verificável na evidência.

## Base de teste e limitação atual

`benchmark/manifest.csv` referencia 20 imagens sintéticas cegas (`E001.png` ... `E020.png`). Elas foram criadas originalmente para o experimento legado CMMI-inspirado 1/5, **não para o novo rubric 4D/NIST Tier 1–4**. O experimento anterior está preservado em `benchmark_legado_1a5/`, explicitamente marcado como histórico. Não converta automaticamente aquelas notas em Tiers.

O novo `benchmark/gabarito_para_validacao.csv` está intencionalmente **em branco e PENDENTE**. Especialistas devem classificar separadamente desenho, implementação, efetividade e Tier indicativo (1–4 ou `NA`), registrando divergências e consenso. Se uma imagem não permitir classificar um critério, use as opções de insuficiência previstas no contrato.

## Execução

Com a API e quota real disponíveis:

```bash
python benchmark/evaluate.py --run --limit 2
python benchmark/evaluate.py --run
python benchmark/evaluate.py --predictions benchmark/resultados/arquivo.csv
```

O script só calcula métricas quando há gabarito 4D marcado `VALIDADO`. Por dimensão, calcula acurácia exata; para Tier determinado, calcula também erro absoluto médio. Não trata falhas HTTP como previsões válidas nem utiliza respostas roteirizadas do modo Demonstração.

## Próximos passos

- Produzir exemplos com todos os rótulos de cada dimensão, incluindo desenho INSUFICIENTE e efetividade NÃO CONCLUSIVO.
- Incluir documentos múltiplos e amostras temporais, pois uma imagem isolada raramente comprova operação sustentada.
- Revisar gabaritos com ao menos dois especialistas e executar repetições para medir estabilidade e latência.
- Comparar versões de prompts/modelos com o mesmo conjunto cego e acompanhar taxas de NÃO DEMONSTRADO, NÃO CONCLUSIVO e Tier não determinado.

**Não foram executadas chamadas Gemini reais neste pacote**, nem há métricas de acurácia reportadas sem gabarito validado. Os testes automatizados cobrem contratos, integração com adaptadores simulados e separação entre modos.
