# Arquivo histórico — não usar como benchmark do novo modelo

Este diretório contém o experimento anterior de maturidade CMMI-inspirada 1–5. Os rótulos 1 e 5 **não correspondem** aos Implementation Tiers 1–4 do NIST CSF 2.0. Mantido somente para rastreabilidade do desenvolvimento; não executar para reportar métricas do modelo atual.
