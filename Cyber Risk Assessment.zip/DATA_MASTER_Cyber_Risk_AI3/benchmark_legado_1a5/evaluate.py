"""Benchmark cego: coleta inferências reais ou pontua previsões já obtidas.

Nunca gera 'resultados de acurácia' fictícios; gabarito ilustrativo exige validação
por especialistas e cobre só os extremos 1/5.
"""
from __future__ import annotations
import argparse
import base64
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import time
from urllib import request, error

ROOT = Path(__file__).resolve().parent


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def calculate_metrics(predictions: list[dict], answer_key: list[dict]) -> dict:
    correct = {item['case_id']: int(item['nota_esperada']) for item in answer_key}
    rows = []
    for row in predictions:
        if row.get('case_id') not in correct or str(row.get('nivel_previsto', '')).strip() == '':
            continue
        try:
            level = int(row['nivel_previsto'])
        except (ValueError, TypeError):
            continue
        if not 1 <= level <= 5:
            continue
        expected = correct[row['case_id']]
        rows.append((row['case_id'], expected, level))
    if not rows:
        return {'total_avaliado': 0, 'total_gabarito': len(correct),
                'aviso': 'Sem previsões válidas. A IA ainda não foi avaliada.'}
    matrix = {str(k): {str(j): 0 for j in range(1, 6)} for k in range(1, 6)}
    for _, exp, pred in rows:
        matrix[str(exp)][str(pred)] += 1
    return {
        'total_avaliado': len(rows),
        'total_gabarito': len(correct),
        'acuracia_exata': round(sum(exp == pred for _, exp, pred in rows) / len(rows), 4),
        'erro_absoluto_medio': round(sum(abs(exp - pred) for _, exp, pred in rows) / len(rows), 4),
        'acuracia_por_nota': {
            str(level): round(sum(exp == pred for _, exp, pred in rows if exp == level) /
                              sum(exp == level for _, exp, pred in rows), 4)
            for level in (1, 5) if any(exp == level for _, exp, pred in rows)
        },
        'matriz_confusao': matrix,
        'limites': ('Gabarito sintético ilustrativo, ainda sem validação SME. '
                    'Só há notas extremas 1 e 5; resultado não generalizável para a escala completa.'),
    }


def run_benchmark(api: str, limit: int, delay: float) -> list[dict]:
    cases = read_csv(ROOT / 'manifest.csv')[:limit or None]
    results = []
    for i, case in enumerate(cases, 1):
        image = (ROOT / 'evidencias' / case['arquivo']).read_bytes()
        data_url = 'data:image/png;base64,' + base64.b64encode(image).decode('ascii')
        payload = json.dumps({'controle_id': case['controle_id'], 'imagem_base64': data_url}).encode('utf-8')
        req = request.Request(api.rstrip('/') + '/api/auditar', data=payload,
                              headers={'Content-Type': 'application/json'}, method='POST')
        try:
            with request.urlopen(req, timeout=180) as resp:
                output = json.loads(resp.read())
            level = int(str(output['nivel_maturidade_nist'])[0])
            row = {'case_id': case['case_id'], 'nivel_previsto': level,
                   'status_controle': output['status_controle'],
                   'confianca_ia': output['confianca_ia'], 'id_analise': output['id_analise']}
            print(f"{i}/{len(cases)} {case['case_id']} -> {level}")
        except (error.URLError, ValueError, KeyError) as exc:
            row = {'case_id': case['case_id'], 'nivel_previsto': '',
                   'erro': type(exc).__name__}
            print(f"{i}/{len(cases)} {case['case_id']} -> erro {type(exc).__name__}")
        results.append(row)
        if delay and i < len(cases):
            time.sleep(delay)
    return results


def write_predictions(path: Path, predictions: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = ['case_id', 'nivel_previsto', 'status_controle', 'confianca_ia', 'id_analise', 'erro']
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        for row in predictions:
            writer.writerow({k: row.get(k, '') for k in columns})


def main():
    p = argparse.ArgumentParser(description='Benchmark de evidências sintéticas 1/5')
    modes = p.add_mutually_exclusive_group(required=True)
    modes.add_argument('--run', action='store_true', help='Executa inferência REAL via API local')
    modes.add_argument('--predictions', type=Path, help='Pontua arquivo CSV de previsões já existentes')
    p.add_argument('--api', default='http://127.0.0.1:8000')
    p.add_argument('--limit', type=int, default=0)
    p.add_argument('--delay', type=float, default=1.0, help='Pausa entre chamadas reais')
    p.add_argument('--out', type=Path, default=None)
    args = p.parse_args()
    key = read_csv(ROOT / 'gabarito.csv')
    if args.run:
        predictions = run_benchmark(args.api, args.limit, args.delay)
        name = 'predictions_' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.csv'
        out = args.out or ROOT / 'resultados' / name
        write_predictions(out, predictions)
        print('Previsões salvas em:', out)
    else:
        predictions = read_csv(args.predictions)
    metrics = calculate_metrics(predictions, key)
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    if args.out and args.predictions:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
